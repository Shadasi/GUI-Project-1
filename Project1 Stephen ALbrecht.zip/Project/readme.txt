Stephen Albrecht
09/14/16

Developed on Eclipse using Windows

No special steps needed.

Bugs:
	The bars go outside of the border when a person has 100% of the votes.
	Not 'technically' a bug, but its a very ugly page
		in addition, i couldn't get the two lists to be next to each other
		so they are stacked.  the bars and the names are in the same order.


Approach:
	I started by just getting a rough layout made and then adding a person to a list.
	After this I got duplicate protection, then deleting working.
	Votes came next, and finally i worked on the bar graph, which took longer than everything else
	and was extremely frustrating.  in the end i didn't even get it to look very nice but it works.